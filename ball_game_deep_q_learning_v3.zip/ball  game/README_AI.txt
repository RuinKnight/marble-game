BALL GAME — DEEP Q-LEARNING AI LAB v3
====================================

WHAT'S NEW
----------
- Replaced tabular Q-learning with a compact Deep Q-Network (DQN).
- Fixed-size, scene-aware observations: the agent sees all visible scene objects in the inspection panel, while the neural network receives the nearest four objects in each category.
- Object geometry accounts for rotation, scale, and camera zoom when determining viewport visibility.
- Camera coordinates of zero are handled correctly.
- Experience replay, a target network, reward shaping, exploration decay, and per-character statistics.
- Network weights and training statistics persist in browser localStorage. Replay samples are intentionally kept in memory to avoid huge persistent storage writes.
- Manual W/A/D movement is disabled while the AI is training.
- Responsive dashboard and on-page startup diagnostics.
- Removed the external jQuery CDN dependency and the jQuery-dependent mobile D-pad initializer. This makes the game more self-contained; it does not override school device policies.

RUNNING
-------
1. Extract the ZIP into a normal folder.
2. Open the folder and open index.html in Chrome.
3. Load one of your level codes using the game's normal level loader (L key in edit mode).
4. Press Space to enter play mode if needed.
5. In BALL GAME AI LAB, choose a character and press Start training.
6. Keep the tab open and active. Learning is performed in the browser; it is not a background cloud job.

DQN DESIGN
----------
- 342 input features: player movement/grounding/pose, goal-relative geometry, camera zoom, character identity, and up to four nearby objects in each of nine categories.
- 64-unit ReLU hidden layer and four action outputs (left, coast, right, jump).
- Epsilon-greedy exploration, 2,200-step episode cap, 6-frame action chunks.
- Experience replay capacity: 2,200 transitions; minibatch: 16.
- Target network synchronization every 180 gradient updates.
- The physics and collision system remain the original game's. DQN controls the selected character through the same velocity changes as a player.

IMPORTANT LIMITATIONS
---------------------
- This is a practical browser-based DQN implementation, not a claim of human-level play. It has not been trained to completion on every level.
- A single nearest-goal reward is used; multi-stage routes, switches, moving platforms, and levels requiring long-term planning may need richer reward signals or curriculum training.
- The game uses its original physics and collision code. DQN cannot learn around a bug in the underlying game mechanics.
- Model weights are saved to localStorage for the same browser profile and file origin. School policies may clear or block local storage.
- Some managed Chromebooks may block local HTML/JavaScript or local file access. This package removes the external jQuery dependency and displays startup diagnostics, but it cannot bypass administrator restrictions. If local files remain blocked, use an administrator-approved static hosting service or a personal device.
- Syntax and archive integrity can be checked offline, but actual Chromebook execution still needs your test.

TROUBLESHOOTING
---------------
If the page is blank, look for the red GAME STARTUP DIAGNOSTIC panel. It should identify a script error or report that the canvas did not initialize. If school policy blocks local execution, ask your administrator which approved hosting environment is allowed.
